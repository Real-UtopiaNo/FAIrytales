# FAIrytales

## Install

```bash
conda create -n fairy python=3.10
conda activate fairy
pip install -r requirements.txt
#pip install edge-tts pyyaml torch diffusers

```

## Run

```bash
python fairy_ai_v1.py
```

