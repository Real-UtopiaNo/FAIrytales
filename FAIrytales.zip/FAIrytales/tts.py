import os
import logging
import yaml
import asyncio
from typing import Dict, List, Optional, Any
from pathlib import Path

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Edge-TTS 角色音色映射 (中文语音)
VOICE_MAPPING = {
    'narrator': 'zh-CN-XiaoxiaoNeural',    # 旁白 - 中性、清晰的女声
    'parent': 'zh-CN-YunxiNeural',         # 父母 - 温暖、成熟的男声
    'child': 'zh-CN-XiaoyiNeural',         # 孩子 - 活泼、年轻的女声
    'friend': 'zh-CN-YunjianNeural',       # 朋友 - 友好、亲切的男声
    'wise': 'zh-CN-YunxiaNeural',          # 智者 - 深沉、稳重的男声
    'gentle': 'zh-CN-XiaohanNeural'        # 温柔 - 柔和、舒缓的女声
}

class EdgeTTSManager:
    """基于Edge-TTS的免费语音合成管理器"""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config = self._load_config(config_path)
        self.edge_tts_available = self._check_edge_tts()
        
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as file:
                return yaml.safe_load(file)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            return {}
    
    def _check_edge_tts(self) -> bool:
        """检查Edge-TTS是否可用"""
        try:
            import edge_tts
            logger.info("Edge-TTS library is available")
            return True
        except ImportError:
            logger.error("Edge-TTS library not installed. Please run: pip install edge-tts")
            return False
    
    def is_available(self) -> bool:
        """检查Edge-TTS是否可用"""
        return self.edge_tts_available
    
    def get_voice_for_role(self, role: str = 'narrator') -> str:
        """根据角色获取对应的音色"""
        return VOICE_MAPPING.get(role, 'zh-CN-XiaoxiaoNeural')
    
    def get_available_voices(self) -> Dict[str, str]:
        """获取所有可用的音色映射"""
        return VOICE_MAPPING.copy()
    
    async def _synthesize_async(self, text: str, voice: str, output_path: str) -> bool:
        """异步语音合成"""
        try:
            import edge_tts
            
            # 创建TTS通信对象
            communicate = edge_tts.Communicate(text, voice)
            
            # 确保输出目录存在
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # 保存音频文件
            await communicate.save(output_path)
            return True
            
        except Exception as e:
            logger.error(f"Edge-TTS async synthesis failed: {e}")
            return False
    
    def synthesize_text(self, text: str, output_path: str, role: str = 'narrator') -> bool:
        """合成单个文本为语音
        
        Args:
            text: 要合成的文本
            output_path: 输出文件路径
            role: 角色类型，用于选择音色
        """
        if not self.is_available():
            logger.error("Edge-TTS not available")
            return False
            
        try:
            # 获取音色配置
            voice = self.get_voice_for_role(role)
            
            logger.info(f"Generating speech: role={role}, voice={voice}")
            logger.info(f"Text preview: {text[:100]}...")
            
            # 运行异步合成
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                success = loop.run_until_complete(
                    self._synthesize_async(text, voice, output_path)
                )
            finally:
                loop.close()
            
            if success and os.path.exists(output_path):
                logger.info(f"Audio saved to: {output_path}")
                return True
            else:
                logger.error("Failed to generate audio file")
                return False
            
        except Exception as e:
            logger.error(f"Edge-TTS synthesis failed: {e}")
            return False
    
    def process_story_for_tts(self, story_data: Dict[str, Any], output_root: str = "books") -> List[str]:
        """为故事的每个部分生成语音文件
        
        Args:
            story_data: 故事数据，包含title和story_parts
            output_root: 输出根目录
            
        Returns:
            生成的音频文件路径列表
        """
        if not story_data:
            logger.error("No story data provided")
            return []
        
        title = story_data.get("title", "untitled_story")
        story_parts = story_data.get("story_parts", [])
        
        if not story_parts:
            logger.error("No story parts found in story data")
            return []
        
        logger.info(f"--- Generating TTS for story '{title}' ---")
        
        # 创建输出目录
        output_dir = os.path.join(output_root, title)
        os.makedirs(output_dir, exist_ok=True)
        logger.info(f"Audio files will be saved under: {output_dir}")
        
        if not self.is_available():
            logger.error("Edge-TTS not available")
            return []
        
        saved_paths = []
        
        for part in story_parts:
            part_number = part.get("part_number", 0)
            content = part.get("content", "")
            
            if not content.strip():
                logger.warning(f"[Part {part_number}] Empty content, skipping")
                continue
            
            # 生成输出文件路径
            audio_path = os.path.join(output_dir, f"voice_{part_number}.wav")
            
            logger.info(f"[Part {part_number}] Generating audio...")
            logger.info(f"[Part {part_number}] Content preview: {content[:100]}...")
            
            try:
                # 根据内容判断角色类型
                role = self._detect_role_from_content(content)
                success = self.synthesize_text(content, audio_path, role)
                
                if success:
                    saved_paths.append(audio_path)
                    logger.info(f"[Part {part_number}] Audio generated successfully with {role} voice")
                else:
                    logger.error(f"[Part {part_number}] Failed to generate audio")
                    
            except Exception as e:
                logger.error(f"[Part {part_number}] TTS generation failed: {e}")
        
        logger.info(f"TTS generation completed. Generated {len(saved_paths)} audio files.")
        return saved_paths
    
    def _detect_role_from_content(self, content: str) -> str:
        """根据内容简单判断角色类型"""
        content_lower = content.lower()
        
        # 简单的关键词匹配
        if any(word in content_lower for word in ['妈妈', '爸爸', '父母', '母亲', '父亲']):
            return 'parent'
        elif any(word in content_lower for word in ['小朋友', '孩子', '宝宝', '小']):
            return 'child'
        elif any(word in content_lower for word in ['朋友', '伙伴', '同伴']):
            return 'friend'
        elif any(word in content_lower for word in ['智者', '老人', '长者', '师父']):
            return 'wise'
        elif any(word in content_lower for word in ['温柔', '轻声', '柔和']):
            return 'gentle'
        else:
            return 'narrator'  # 默认旁白

    async def list_available_voices(self) -> List[Dict[str, str]]:
        """列出所有可用的Edge-TTS语音"""
        try:
            import edge_tts
            voices = await edge_tts.list_voices()
            
            # 过滤中文语音
            chinese_voices = []
            for voice in voices:
                if voice['Locale'].startswith('zh-'):
                    chinese_voices.append({
                        'name': voice['Name'],
                        'display_name': voice['DisplayName'],
                        'locale': voice['Locale'],
                        'gender': voice['Gender']
                    })
            
            return chinese_voices
            
        except Exception as e:
            logger.error(f"Failed to list voices: {e}")
            return []

# 便捷函数
def generate_story_audio(story_data: Dict[str, Any], config_path: str = "config.yaml") -> List[str]:
    """便捷函数：为故事生成语音文件"""
    tts_manager = EdgeTTSManager(config_path)
    return tts_manager.process_story_for_tts(story_data)

def test_tts():
    """测试TTS功能"""
    test_story = {
        "title": "Edge-TTS测试故事",
        "story_parts": [
            {
                "part_number": 1,
                "content": "这是一个测试故事的第一段。小熊在森林里快乐地玩耍。",
                "image_prompt": "A bear playing in the forest"
            },
            {
                "part_number": 2,
                "content": "妈妈温柔地说：'小熊，该回家了。'",
                "image_prompt": "A mother bear calling her cub"
            },
            {
                "part_number": 3,
                "content": "小朋友们都很喜欢这个故事。",
                "image_prompt": "Children enjoying a story"
            }
        ]
    }
    
    print("🎵 测试Edge-TTS功能...")
    tts_manager = EdgeTTSManager()
    
    if not tts_manager.is_available():
        print("❌ Edge-TTS不可用，请安装: pip install edge-tts")
        return
    
    print("✓ Edge-TTS可用")
    result = tts_manager.process_story_for_tts(test_story)
    print(f"生成的音频文件: {result}")

async def show_available_voices():
    """显示所有可用的中文语音"""
    print("🎵 Edge-TTS 可用中文语音:")
    tts_manager = EdgeTTSManager()
    
    if not tts_manager.is_available():
        print("❌ Edge-TTS不可用")
        return
    
    voices = await tts_manager.list_available_voices()
    
    print(f"\n找到 {len(voices)} 个中文语音:")
    for voice in voices:
        print(f"  - {voice['display_name']} ({voice['name']})")
        print(f"    地区: {voice['locale']}, 性别: {voice['gender']}")
    
    print(f"\n当前角色音色映射:")
    for role, voice_name in VOICE_MAPPING.items():
        print(f"  - {role}: {voice_name}")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "voices":
        # 显示可用语音
        asyncio.run(show_available_voices())
    else:
        # 运行测试
        test_tts()