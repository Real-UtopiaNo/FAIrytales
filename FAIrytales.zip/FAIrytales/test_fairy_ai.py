#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fairy AI 测试脚本
用于测试文本生成和语音合成功能
"""

import os
import sys
import subprocess
import time

def check_dependencies():
    """检查依赖项"""
    print("=== 检查依赖项 ===")
    
    required_files = [
        "config.yaml",
        "prompt.py", 
        "generate.py",
        "tts.py",
        "fairy_ai_v1 copy.py"
    ]
    
    missing_files = []
    for file in required_files:
        if os.path.exists(file):
            print(f"✓ {file}")
        else:
            print(f"✗ {file} (缺失)")
            missing_files.append(file)
    
    if missing_files:
        print(f"\n❌ 缺失文件: {missing_files}")
        return False
    
    print("✓ 所有必需文件都存在")
    return True

def check_config():
    """检查配置文件"""
    print("\n=== 检查配置文件 ===")
    
    try:
        import yaml
        with open("config.yaml", "r", encoding='utf-8') as file:
            config = yaml.safe_load(file)
        
        required_keys = ['title', 'characters', 'lesson', 'style', 'language']
        for key in required_keys:
            if key in config:
                print(f"✓ {key}: {config[key]}")
            else:
                print(f"⚠ {key}: 未设置")
        
        return True
    except Exception as e:
        print(f"✗ 配置文件读取失败: {e}")
        return False

def run_test():
    """运行测试"""
    print("\n=== 开始测试 ===")
    print("正在运行 fairy_ai_v1 copy.py...")
    print("注意: 这可能需要几分钟时间，请耐心等待...")
    
    try:
        # 运行主程序
        result = subprocess.run([
            sys.executable, "fairy_ai_v1 copy.py"
        ], capture_output=True, text=True, encoding='utf-8')
        
        print("\n--- 程序输出 ---")
        if result.stdout:
            print(result.stdout)
        
        if result.stderr:
            print("\n--- 错误信息 ---")
            print(result.stderr)
        
        if result.returncode == 0:
            print("\n✓ 程序执行成功")
            return True
        else:
            print(f"\n✗ 程序执行失败 (返回码: {result.returncode})")
            return False
            
    except Exception as e:
        print(f"\n✗ 运行测试时出错: {e}")
        return False

def check_output():
    """检查输出结果"""
    print("\n=== 检查输出结果 ===")
    
    books_dir = "books"
    if not os.path.exists(books_dir):
        print("✗ books 目录不存在")
        return False
    
    # 查找最新创建的故事目录
    story_dirs = [d for d in os.listdir(books_dir) if os.path.isdir(os.path.join(books_dir, d))]
    
    if not story_dirs:
        print("✗ 没有找到故事目录")
        return False
    
    # 检查最新的故事目录
    latest_dir = max(story_dirs, key=lambda d: os.path.getctime(os.path.join(books_dir, d)))
    story_path = os.path.join(books_dir, latest_dir)
    
    print(f"检查故事目录: {story_path}")
    
    # 检查文件
    files = os.listdir(story_path)
    
    # 检查故事文本文件
    if "story.json" in files:
        print("✓ story.json (故事文本)")
    else:
        print("⚠ story.json 不存在")
    
    # 检查语音文件
    audio_files = [f for f in files if f.endswith('.wav')]
    if audio_files:
        print(f"✓ 找到 {len(audio_files)} 个语音文件:")
        for audio_file in audio_files:
            file_path = os.path.join(story_path, audio_file)
            file_size = os.path.getsize(file_path)
            print(f"  - {audio_file} ({file_size} bytes)")
    else:
        print("⚠ 没有找到语音文件")
    
    return True

def main():
    """主测试函数"""
    print("Fairy AI 功能测试")
    print("=" * 50)
    
    # 切换到脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    # 执行测试步骤
    steps = [
        ("检查依赖项", check_dependencies),
        ("检查配置文件", check_config),
        ("运行测试", run_test),
        ("检查输出结果", check_output)
    ]
    
    for step_name, step_func in steps:
        print(f"\n{'='*20} {step_name} {'='*20}")
        try:
            success = step_func()
            if not success:
                print(f"\n❌ {step_name} 失败，测试终止")
                return False
        except Exception as e:
            print(f"\n❌ {step_name} 出现异常: {e}")
            return False
    
    print(f"\n{'='*50}")
    print("🎉 所有测试步骤完成！")
    print("\n测试总结:")
    print("- ✓ 文本生成功能正常")
    print("- ✓ 语音合成功能正常") 
    print("- ✓ 图像生成已跳过")
    print("\n请检查 books/ 目录下的输出文件")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)