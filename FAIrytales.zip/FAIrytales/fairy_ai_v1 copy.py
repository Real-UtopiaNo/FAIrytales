import yaml
import os
import json
from prompt import *
# from generate import *
# from t2i import *
from tts import *
from generate import generate_and_parse_story # 只导入我们需要的统一函数
# from image_generator import process_story_for_images # 图片处理函数已跳过

"""
Create config from yaml file. Example of config:

{'title': '小熊的奇幻冒险', 'characters': [{'name': '小熊', 'trait': '勇敢'}, 
{'name': '狐狸', 'trait': '聪明'}], 'lesson': '要诚实守信', 'style': '温馨治愈', 'language': 'zh', 'voice': 'female'}
"""
with open("config.yaml", "r", encoding='utf-8') as file:
    config = yaml.safe_load(file)


"""
Get prompt for LLM, then pass it to API, return title, parts, t2iprompts, ......
"""
# 1. 保持 prompt 生成逻辑不变
prompt = generate_prompt(config=config)
print("--- Generating story with the following prompt ---")
print(prompt)

# 2. 调用统一的生成和解析函数
structured_story = generate_and_parse_story(prompt=prompt)


# 3. 打印最终的结构化数据
if structured_story:
    print("\n--- Successfully generated and parsed story ---")
    print(json.dumps(structured_story, indent=2, ensure_ascii=False))

    # 跳过图像生成，直接测试语音功能
    print("\n--- Skipping image generation for testing ---")
    print("--- Testing TTS functionality only ---")
    
    # 添加调试信息来验证数据结构
    print("\n--- DEBUG: Checking structured_story for TTS ---")
    print(f"structured_story type: {type(structured_story)}")
    if structured_story and 'story_parts' in structured_story:
        print(f"story_parts type: {type(structured_story['story_parts'])}")
        if isinstance(structured_story['story_parts'], str):
            print("WARNING: story_parts is a string, not a list!")
            print(f"story_parts content: {structured_story['story_parts'][:200]}...")
            # 尝试解析字符串为JSON
            try:
                import json
                parsed_parts = json.loads(structured_story['story_parts'])
                print(f"Successfully parsed story_parts as JSON: {type(parsed_parts)}")
                structured_story['story_parts'] = parsed_parts
            except Exception as parse_error:
                print(f"Failed to parse story_parts as JSON: {parse_error}")
        else:
            print(f"story_parts length: {len(structured_story['story_parts']) if isinstance(structured_story['story_parts'], (list, tuple)) else 'Not a list/tuple'}")
            if isinstance(structured_story['story_parts'], (list, tuple)) and len(structured_story['story_parts']) > 0:
                print(f"First part type: {type(structured_story['story_parts'][0])}")
                print(f"First part keys: {structured_story['story_parts'][0].keys() if isinstance(structured_story['story_parts'][0], dict) else 'Not a dict'}")
    
    # 生成语音文件
    print("\n--- Handing off to TTS generator ---")
    from tts import generate_story_audio
    try:
        audio_paths = generate_story_audio(structured_story)
        print(f"Generated {len(audio_paths)} audio files:")
        for path in audio_paths:
            print(f"  - {path}")
    except Exception as e:
        print(f"TTS generation failed: {e}")
        print("Continuing without audio files...")
        import traceback
        traceback.print_exc()
    
    print(f"\n--- Story generation completed ---")
    print(f"Title: {structured_story['title']}")
    print(f"Generated {len(audio_paths) if 'audio_paths' in locals() else 0} audio files")
    
else:
    print("\n--- Failed to get structured story after all attempts. ---")


# 创建输出目录并保存结果
    try:
        title = structured_story.get('title', 'untitled_story')
        output_dir = os.path.join("books", title)
        os.makedirs(output_dir, exist_ok=True)
        
        # 保存故事文本
        story_file = os.path.join(output_dir, "story.json")
        with open(story_file, 'w', encoding='utf-8') as f:
            json.dump(structured_story, f, indent=2, ensure_ascii=False)
        print(f"✓ 故事文本已保存到: {story_file}")
        
        print(f"\n=== 处理完成 ===")
        print(f"故事标题: {title}")
        print(f"输出目录: {output_dir}")
        print("注意: 图像生成已跳过，只生成了文本和语音")
        
    except Exception as e:
        print(f"⚠ 保存文件时出错: {e}")
        import traceback
        traceback.print_exc()