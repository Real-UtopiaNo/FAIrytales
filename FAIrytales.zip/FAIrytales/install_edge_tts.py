#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Edge-TTS 快速安装和测试脚本
自动安装依赖并测试TTS功能
"""

import subprocess
import sys
import os

def run_command(command, description):
    """运行命令并显示结果"""
    print(f"\n🔧 {description}...")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ {description}成功")
            if result.stdout.strip():
                print(f"输出: {result.stdout.strip()}")
            return True
        else:
            print(f"❌ {description}失败")
            if result.stderr.strip():
                print(f"错误: {result.stderr.strip()}")
            return False
    except Exception as e:
        print(f"❌ {description}失败: {e}")
        return False

def check_python_version():
    """检查Python版本"""
    print("🐍 检查Python版本...")
    version = sys.version_info
    print(f"当前Python版本: {version.major}.{version.minor}.{version.micro}")
    
    if version.major >= 3 and version.minor >= 7:
        print("✅ Python版本符合要求 (>= 3.7)")
        return True
    else:
        print("❌ Python版本过低，需要Python 3.7或更高版本")
        return False

def install_edge_tts():
    """安装Edge-TTS"""
    print("\n📦 安装Edge-TTS...")
    
    # 尝试安装edge-tts
    success = run_command("pip install edge-tts>=6.1.0", "安装edge-tts")
    if not success:
        print("尝试使用国内镜像安装...")
        success = run_command("pip install -i https://pypi.tuna.tsinghua.edu.cn/simple edge-tts>=6.1.0", "使用清华镜像安装edge-tts")
    
    return success

def install_dependencies():
    """安装其他依赖"""
    print("\n📦 安装其他依赖...")
    
    dependencies = [
        "PyYAML>=6.0",
        "Pillow>=9.0.0"
    ]
    
    all_success = True
    for dep in dependencies:
        success = run_command(f"pip install {dep}", f"安装{dep}")
        if not success:
            all_success = False
    
    return all_success

def test_edge_tts():
    """测试Edge-TTS功能"""
    print("\n🧪 测试Edge-TTS功能...")
    
    try:
        import edge_tts
        import asyncio
        
        print("✅ edge-tts库导入成功")
        
        # 测试简单的TTS功能
        async def test_synthesis():
            try:
                communicate = edge_tts.Communicate("你好，这是Edge-TTS测试", "zh-CN-XiaoxiaoNeural")
                test_file = "edge_tts_test.wav"
                await communicate.save(test_file)
                
                if os.path.exists(test_file):
                    file_size = os.path.getsize(test_file)
                    print(f"✅ 语音合成测试成功，生成文件大小: {file_size} 字节")
                    os.remove(test_file)  # 清理测试文件
                    return True
                else:
                    print("❌ 语音合成测试失败，未生成文件")
                    return False
                    
            except Exception as e:
                print(f"❌ 语音合成测试失败: {e}")
                return False
        
        # 运行异步测试
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            success = loop.run_until_complete(test_synthesis())
        finally:
            loop.close()
        
        return success
        
    except ImportError as e:
        print(f"❌ edge-tts库导入失败: {e}")
        return False
    except Exception as e:
        print(f"❌ Edge-TTS测试失败: {e}")
        return False

def show_usage_info():
    """显示使用说明"""
    print("\n" + "="*60)
    print("🎉 Edge-TTS安装完成！")
    print("="*60)
    print("\n📖 使用说明:")
    print("1. 运行完整测试: python test_tts.py")
    print("2. 查看可用语音: python test_tts.py voices")
    print("3. 运行主程序: python fairy_ai_v1.py")
    print("\n🎵 Edge-TTS优势:")
    print("• 完全免费，无需API密钥")
    print("• 高质量语音，接近商业级别")
    print("• 支持多种中文音色")
    print("• 无使用限制，稳定可靠")
    print("\n📚 更多信息请查看 README.md")

def main():
    """主安装流程"""
    print("🎵 Edge-TTS 自动安装脚本")
    print("="*60)
    print("这个脚本将帮助您安装和配置Edge-TTS免费语音合成系统")
    
    # 检查Python版本
    if not check_python_version():
        print("\n❌ 安装失败：Python版本不符合要求")
        return False
    
    # 安装Edge-TTS
    if not install_edge_tts():
        print("\n❌ 安装失败：无法安装edge-tts")
        return False
    
    # 安装其他依赖
    if not install_dependencies():
        print("\n⚠️ 警告：部分依赖安装失败，但Edge-TTS应该可以正常工作")
    
    # 测试功能
    if test_edge_tts():
        print("\n✅ 所有测试通过！")
        show_usage_info()
        return True
    else:
        print("\n❌ 测试失败，请检查网络连接或手动安装")
        print("\n手动安装命令:")
        print("pip install edge-tts PyYAML Pillow")
        return False

if __name__ == "__main__":
    try:
        success = main()
        if success:
            print("\n🎉 安装成功！现在可以使用Edge-TTS了。")
        else:
            print("\n❌ 安装过程中遇到问题，请查看上面的错误信息。")
    except KeyboardInterrupt:
        print("\n\n⚠️ 安装被用户中断")
    except Exception as e:
        print(f"\n❌ 安装过程中发生未知错误: {e}")