# Edge-TTS 免费语音合成说明

## 🎵 概述

FAIrytales现在使用**Edge-TTS**作为语音合成引擎，这是一个完全免费的解决方案，无需任何API密钥。

## ✅ 优势

- **完全免费** - 无需API密钥或付费账号
- **高质量语音** - 使用微软Edge同款TTS引擎
- **多种中文音色** - 支持6种不同角色音色
- **无使用限制** - 没有次数或时长限制

## 🚀 快速开始

### 安装依赖
```bash
pip install edge-tts>=6.1.0
```

### 测试功能
```bash
# 运行完整测试
python test_tts.py

# 查看可用语音
python test_tts.py voices

# 显示帮助
python test_tts.py help
```

## 🎭 角色音色映射

系统会根据故事内容自动选择合适的音色：

| 角色类型 | 音色 | 特点 |
|---------|------|------|
| narrator (旁白) | zh-CN-XiaoxiaoNeural | 中性、清晰的女声 |
| parent (父母) | zh-CN-YunxiNeural | 温暖、成熟的男声 |
| child (孩子) | zh-CN-XiaoyiNeural | 活泼、年轻的女声 |
| friend (朋友) | zh-CN-YunjianNeural | 友好、亲切的男声 |
| wise (智者) | zh-CN-YunxiaNeural | 深沉、稳重的男声 |
| gentle (温柔) | zh-CN-XiaohanNeural | 柔和、舒缓的女声 |

## ⚙️ 配置

在 `config.yaml` 中可以自定义音色设置：

```yaml
tts:
  engine: "edge-tts"
  voices:
    narrator: "zh-CN-XiaoxiaoNeural"
    parent: "zh-CN-YunxiNeural"
    # ... 其他角色
  settings:
    rate: "+0%"      # 语速调节
    volume: "+0%"    # 音量调节
    pitch: "+0Hz"    # 音调调节
```

## 💻 API使用

```python
from tts import EdgeTTSManager, generate_story_audio

# 方法1：使用便捷函数
story_data = {
    "title": "我的故事",
    "story_parts": [
        {
            "part_number": 1,
            "content": "故事内容...",
            "image_prompt": "图片描述"
        }
    ]
}
audio_paths = generate_story_audio(story_data)

# 方法2：直接使用管理器
tts_manager = EdgeTTSManager()
success = tts_manager.synthesize_text(
    text="你好，世界！",
    output_path="output.wav",
    role="narrator"
)
```

## 🔧 故障排除

### TTS不工作
1. 检查安装：`pip install edge-tts`
2. 确认网络连接正常
3. 运行测试：`python test_tts.py`

### 常见问题
- **首次使用较慢**：需要下载语音模型，属于正常现象
- **网络错误**：确保能访问微软服务
- **音频文件损坏**：检查磁盘空间和权限

## 🆚 与OpenAI TTS对比

| 特性 | Edge-TTS | OpenAI TTS |
|------|----------|------------|
| 费用 | ✅ 免费 | ❌ 付费 |
| API密钥 | ✅ 不需要 | ❌ 需要 |
| 语音质量 | ✅ 高质量 | ✅ 高质量 |
| 使用限制 | ✅ 无限制 | ❌ 有限制 |

## 📁 输出文件

语音文件保存在 `books/故事标题/` 目录：
```
books/
└── 故事标题/
    ├── voice_1.wav
    ├── voice_2.wav
    └── ...
```

## 🛠️ 开发者信息

- **TTS引擎**: Microsoft Edge-TTS
- **Python库**: edge-tts>=6.1.0
- **支持格式**: WAV音频文件
- **异步处理**: 使用asyncio提高性能

---

**🎉 享受免费的高质量语音合成！**